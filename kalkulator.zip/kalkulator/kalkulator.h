#ifndef KALKULATOR_H
#define KALKULATOR_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class kalkulator;
}
QT_END_NAMESPACE

class kalkulator : public QMainWindow
{
    Q_OBJECT

public:
    kalkulator(QWidget *parent = nullptr);
    ~kalkulator();
    void reset() {
        ram = 0;
        first = false;
    }

    double dodaj(double a, double b) {
        first = true;
        ram = a + b;
        return ram;
    }

    double odejmij(double a, double b) {
        first = true;
        ram = a - b;
        return ram;
    }

    double mnoz(double a, double b) {
        first = true;
        ram = a * b;
        return ram;
    }

    double dziel(double a, double b) {
        if (b != 0) {
            first = true;
            ram = a / b;
            return ram;
        }
        return 0;
    }
    double modulo(double a, double b) {
        ram = static_cast<int>(a) % static_cast<int>(b);
        first = true;
        return ram;
    }

private:
    double ram = 0.0;
    bool first = false;
    Ui::kalkulator *ui;

private slots:
    void NumPressed();
    void MathButtonPressed();
    void EqualButton();
    void on_OFF_pressed();
    void DotPressed();
    void NEGATIVEPressed();
    void on_actionauthor_triggered();
};
#endif // KALKULATOR_H
