#include "kalkulator.h"
#include "ui_kalkulator.h"
#include "QMessageBox"

double calcVal = 0.0;
bool divTrigger = false;
bool multTrigger = false;
bool addTrigger = false;
bool subTrigger = false;
bool modTrigger = false;
bool eraseTrigger = false;
bool negativeTrigger = false;
bool userIsTypingSecondNumber = false;

kalkulator::kalkulator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::kalkulator)
{
    ui->setupUi(this);

    ui->Display->setText(QString::number(calcVal));
    QPushButton *numButtons[10];
    for(int i = 0; i < 10; ++i) {
        QString butName = "NUMBER" + QString::number(i);
        numButtons[i] = kalkulator::findChild<QPushButton*>(butName);
        connect(numButtons[i], SIGNAL(released()), this,
                SLOT(NumPressed()));
    }
    connect(ui->ADDITION, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->SUBSTRACTION, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->MULTIPLICATION, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->DIVIDE, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->MOD, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->ERASE, SIGNAL(released()), this, SLOT(MathButtonPressed()));
    connect(ui->DOT, SIGNAL(released()), this, SLOT(DotPressed()));
    connect(ui->NEGATIVE, SIGNAL(released()), this, SLOT(NEGATIVEPressed()));

    connect(ui->EUQAL, SIGNAL(released()), this, SLOT(EqualButton()));
}

kalkulator::~kalkulator() {
    delete ui;
}

void kalkulator::NumPressed() {
    QPushButton *button = (QPushButton *)sender();
    QString butVal = button->text();
    QString displayVal = ui->Display->text();

    // Jeśli na wyświetlaczu jest operator albo to druga liczba – nadpisujemy
    if (displayVal == "+" || displayVal == "-" || displayVal == "*" ||
        displayVal == "/" || displayVal == "MOD" || userIsTypingSecondNumber) {
        ui->Display->setText(butVal);
        userIsTypingSecondNumber = false;
    } else {
        QString newVal = displayVal + butVal;
        double dblNewVal = newVal.toDouble();
        ui->Display->setText(QString::number(dblNewVal, 'g', 16));
    }
}

void kalkulator::MathButtonPressed() {
    // Reset flag operatorów
    divTrigger = multTrigger = addTrigger = subTrigger = modTrigger = negativeTrigger = false;

    // Zczytujemy liczbę z wyświetlacza
    QString displayVal = ui->Display->text();
    calcVal = displayVal.toDouble();

    // Sprawdzamy, który przycisk został kliknięty
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    QString butVal = button->text();

    // Ustawiamy odpowiednią flagę i wyświetlamy operator
    if (butVal == "/") {
        divTrigger = true;
        ui->Display->setText("/");
    } else if (butVal == "+") {
        addTrigger = true;
        ui->Display->setText("+");
    } else if (butVal == "-") {
        subTrigger = true;
        ui->Display->setText("-");
    } else if (butVal == "*") {
        multTrigger = true;
        ui->Display->setText("*");
    } else if (butVal == "MOD") {
        modTrigger = true;
        ui->Display->setText("MOD");
    } else if (butVal == "ERASE") {
        eraseTrigger = true;
        ui->Display->setText("0");  // Wyświetlamy "0" po kliknięciu ERASE
    }

    // Po kliknięciu operatora – użytkownik wpisuje drugą liczbę
    userIsTypingSecondNumber = true;
}

void kalkulator::EqualButton() {
    double solution = 0.0;
    QString displayVal = ui->Display->text();
    double dblDisplayVal = displayVal.toDouble();

    if (addTrigger) {
        solution = dodaj(calcVal, dblDisplayVal);
    } else if (subTrigger) {
        solution = odejmij(calcVal, dblDisplayVal);
    } else if (multTrigger) {
        solution = mnoz(calcVal, dblDisplayVal);
    } else if (divTrigger) {
        if (dblDisplayVal == 0) {
            ui->Display->setText("ERR: /0");
            return;
        }
        solution = dziel(calcVal, dblDisplayVal);
    } else if (modTrigger) {
        if (dblDisplayVal == 0) {
            ui->Display->setText("ERR: /0");
            return;
        }
        solution = modulo(calcVal, dblDisplayVal);
    } else if (eraseTrigger) {
        solution = 0.0;  // Resetujemy wartość po kliknięciu ERASE
    }

    eraseTrigger = false; // Resetujemy eraseTrigger po użyciu
    ui->Display->setText(QString::number(solution));
}

void kalkulator::on_OFF_pressed()
{
    close();
}

void kalkulator::DotPressed() {
    QString displayVal = ui->Display->text();

    // Dodaj kropkę tylko jeśli jeszcze jej nie ma
    if (!displayVal.contains(".")) {
        ui->Display->setText(displayVal + ".");
    }
}

void kalkulator::NEGATIVEPressed() {
    QString displayVal = ui->Display->text();
    double dblVal = displayVal.toDouble();

    dblVal *= -1;

    ui->Display->setText(QString::number(dblVal, 'g', 16));
}

void kalkulator::on_actionauthor_triggered()
{
    QMessageBox::information(this, "O autorze",
        "Autor: Wojciech Benkiewicz\nIndeks: 287118\nProjekt: Kalkulator");
}

