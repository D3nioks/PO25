#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_N_1_clicked()
{
    ui->textEdit->setText("1");
}


void MainWindow::on_N_2_clicked()
{
    ui->textEdit->setText("2");
}


void MainWindow::on_N_3_clicked()
{
     ui->textEdit->setText("3");
}


void MainWindow::on_N_4_clicked()
{
    ui->textEdit->setText("4");
}


void MainWindow::on_N_5_clicked()
{
    ui->textEdit->setText("5");
}


void MainWindow::on_N_6_clicked()
{
    ui->textEdit->setText("6");
}


void MainWindow::on_N_7_clicked()
{
    ui->textEdit->setText("7");
}


void MainWindow::on_N_8_clicked()
{
    ui->textEdit->setText("8");
}


void MainWindow::on_N_9_clicked()
{
    ui->textEdit->setText("9");
}


void MainWindow::on_N_0_clicked()
{
    ui->textEdit->setText("0");
}


void MainWindow::on_equal_clicked()
{
     ui->textEdit->setText("=");
}


void MainWindow::on_erase_clicked()
{
     ui->textEdit->setText("erase");
}


void MainWindow::on_divide_clicked()
{
     ui->textEdit->setText("/");
}


void MainWindow::on_multiply_clicked()
{
     ui->textEdit->setText("*");
}


void MainWindow::on_addition_clicked()
{
     ui->textEdit->setText("+");
}


void MainWindow::on_subtraction_clicked()
{
     ui->textEdit->setText("-");
}


void MainWindow::on_exit_clicked()
{
     ui->textEdit->setText("EXIT");
}


void MainWindow::on_modulo_clicked()
{
     ui->textEdit->setText("MOD");
}

